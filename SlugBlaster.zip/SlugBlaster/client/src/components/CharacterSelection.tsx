
import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";

interface Character {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  speciality: string;
}

const characters: Character[] = [
  {
    id: 'reina',
    name: '레이나',
    description: '권총 전문가',
    imageUrl: 'https://i.imgur.com/IbnEwGC.jpg',
    speciality: 'pistol'
  },
  {
    id: 'sera',
    name: '세라',
    description: '스나이퍼',
    imageUrl: 'https://i.imgur.com/TC5tFmj.jpg',
    speciality: 'sniper'
  },
  {
    id: 'mika',
    name: '미카',
    description: '기관총병',
    imageUrl: 'https://i.imgur.com/N84ZCkC.jpg',
    speciality: 'machinegun'
  },
  {
    id: 'luna',
    name: '루나',
    description: '쌍권총',
    imageUrl: 'https://i.imgur.com/kH65mZu.jpg',
    speciality: 'dualgun'
  }
];

interface CharacterSelectionProps {
  onCharacterSelect: (character: Character) => void;
}

export default function CharacterSelection({ onCharacterSelect }: CharacterSelectionProps) {
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);

  const handleCharacterSelect = (character: Character) => {
    setSelectedCharacter(character);
  };

  const handleStartGame = () => {
    if (selectedCharacter) {
      onCharacterSelect(selectedCharacter);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gray-900 text-cyan-400 flex flex-col items-center justify-center p-5 font-mono">
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: "url('https://www.transparenttextures.com/patterns/dark-mosaic.png')"
        }}
      />
      
      <div className="relative z-10">
        <h1 className="text-4xl font-bold text-pink-400 mb-8 text-shadow">
          🔫 미녀 요원 중 한 명을 선택하세요 🔫
        </h1>

        <div className="flex justify-center flex-wrap gap-4 mb-8">
          {characters.map((character) => {
            const getCharacterStyle = (characterId: string) => {
              switch (characterId) {
                case 'reina':
                  return {
                    bg: 'bg-red-950',
                    border: 'border-red-400',
                    hoverShadow: 'hover:shadow-red-400/50',
                    activeShadow: 'shadow-red-400/50'
                  };
                case 'sera':
                  return {
                    bg: 'bg-blue-950',
                    border: 'border-cyan-400',
                    hoverShadow: 'hover:shadow-cyan-400/50',
                    activeShadow: 'shadow-cyan-400/50'
                  };
                case 'mika':
                  return {
                    bg: 'bg-green-950',
                    border: 'border-green-400',
                    hoverShadow: 'hover:shadow-green-400/50',
                    activeShadow: 'shadow-green-400/50'
                  };
                case 'luna':
                  return {
                    bg: 'bg-purple-950',
                    border: 'border-purple-400',
                    hoverShadow: 'hover:shadow-purple-400/50',
                    activeShadow: 'shadow-purple-400/50'
                  };
                default:
                  return {
                    bg: 'bg-gray-800',
                    border: 'border-cyan-400',
                    hoverShadow: 'hover:shadow-cyan-400/50',
                    activeShadow: 'shadow-cyan-400/50'
                  };
              }
            };

            const style = getCharacterStyle(character.id);
            
            return (
              <Card 
                key={character.id}
                className={`
                  ${style.bg} border-2 ${style.border} cursor-pointer transition-all duration-300
                  hover:scale-105 ${style.hoverShadow} hover:shadow-lg
                  w-36 h-64 relative rounded-lg p-2
                  ${selectedCharacter?.id === character.id 
                    ? `${style.activeShadow} shadow-lg scale-105` 
                    : 'shadow-lg shadow-white/20'
                  }
                `}
                onClick={() => handleCharacterSelect(character)}
              >
                <CardContent className="p-2">
                  <div className="sprite-container w-full h-48 mb-2 rounded-md overflow-hidden">
                    <img 
                      src={character.imageUrl} 
                      alt={character.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="text-white font-bold text-sm">
                    {character.name} ({character.description})
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {selectedCharacter && (
          <div className="text-center mb-6">
            <p className="text-xl text-red-400 mb-4">
              {selectedCharacter.name} 요원을 선택하셨습니다!
            </p>
            <Button 
              onClick={handleStartGame}
              className="
                bg-gray-900 border-2 border-cyan-400 text-cyan-400 px-6 py-3 text-lg
                hover:bg-cyan-400 hover:text-black hover:border-black
                shadow-lg shadow-cyan-400/30 hover:shadow-cyan-400/50
              "
            >
              🚀 게임 시작
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
