import { useEffect, useRef, useState } from "react";
import { GameEngine } from "../lib/GameEngine";
import { useAudio } from "../lib/stores/useAudio";

interface Character {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  speciality: string;
}

interface GameProps {
  selectedCharacter: Character | null;
  onBackToSelection: () => void;
}

export default function Game({ selectedCharacter, onBackToSelection }: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [gameOver, setGameOver] = useState(false);
  const { playHit, playSuccess, toggleMute, isMuted } = useAudio();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = 800;
    canvas.height = 600;

    // Initialize game engine
    gameEngineRef.current = new GameEngine(ctx, canvas.width, canvas.height);
    
    // Set up game callbacks
    gameEngineRef.current.onScoreUpdate = (newScore: number) => {
      setScore(newScore);
      playSuccess();
    };
    
    gameEngineRef.current.onPlayerHit = () => {
      playHit();
      setLives(prev => {
        const newLives = prev - 1;
        if (newLives <= 0) {
          setGameOver(true);
          gameEngineRef.current?.stop();
        }
        return newLives;
      });
    };

    // Start the game
    gameEngineRef.current.start();

    // Cleanup
    return () => {
      gameEngineRef.current?.stop();
    };
  }, [playHit, playSuccess]);

  const handleRestart = () => {
    setScore(0);
    setLives(3);
    setGameOver(false);
    
    if (gameEngineRef.current) {
      gameEngineRef.current.restart();
      gameEngineRef.current.start();
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white p-4">
      <div className="mb-4 flex justify-between items-center w-full max-w-2xl">
        <div className="text-xl font-bold">Score: {score}</div>
        <div className="text-xl font-bold">Lives: {lives}</div>
        <button 
          onClick={toggleMute}
          className="px-4 py-2 bg-gray-700 rounded hover:bg-gray-600 transition-colors"
        >
          {isMuted ? "🔇" : "🔊"}
        </button>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          className="border-2 border-gray-600 bg-black"
          style={{ imageRendering: "pixelated" }}
        />
        
        {gameOver && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex flex-col items-center justify-center">
            <h2 className="text-4xl font-bold mb-4">Game Over!</h2>
            <p className="text-xl mb-4">Final Score: {score}</p>
            <button
              onClick={handleRestart}
              className="px-6 py-3 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors text-lg font-semibold"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      <div className="mt-4 text-center text-gray-400">
        <p>Use WASD or Arrow Keys to move • SPACE to shoot • ESC to pause</p>
        {selectedCharacter && (
          <p className="mt-2 text-cyan-400">
            Playing as: <span className="text-pink-400 font-bold">{selectedCharacter.name}</span> ({selectedCharacter.description})
          </p>
        )}
        <button 
          onClick={onBackToSelection}
          className="mt-2 px-4 py-2 text-sm bg-gray-700 hover:bg-gray-600 text-white rounded border border-gray-500"
        >
          ← Back to Character Selection
        </button>
      </div>
    </div>
  );
}
