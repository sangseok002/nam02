export class InputHandler {
  private keys: Set<string> = new Set();
  private keyPressHandlers: Map<string, () => void> = new Map();

  constructor() {
    this.setupEventListeners();
  }

  private setupEventListeners() {
    window.addEventListener("keydown", (event) => {
      this.keys.add(event.code);
      
      // Handle key press events (for single-press actions)
      const handler = this.keyPressHandlers.get(event.code);
      if (handler) {
        handler();
      }
    });

    window.addEventListener("keyup", (event) => {
      this.keys.delete(event.code);
    });

    // Prevent context menu on right click
    window.addEventListener("contextmenu", (event) => {
      event.preventDefault();
    });

    // Handle focus loss to prevent stuck keys
    window.addEventListener("blur", () => {
      this.keys.clear();
    });
  }

  isKeyPressed(key: string): boolean {
    return this.keys.has(key);
  }

  onKeyPress(key: string, handler: () => void) {
    this.keyPressHandlers.set(key, handler);
  }

  // Clean up event listeners if needed
  destroy() {
    this.keyPressHandlers.clear();
  }
}
