export class Bullet {
  public x: number;
  public y: number;
  public width: number = 8;
  public height: number = 3;
  public pierce: boolean;
  public color: string;
  private velocityX: number;
  private velocityY: number;

  constructor(x: number, y: number, velocityX: number, velocityY: number, color: string = "#FFEB3B", pierce: boolean = false) {
    this.x = x;
    this.y = y;
    this.velocityX = velocityX;
    this.velocityY = velocityY;
    this.color = color;
    this.pierce = pierce;
  }

  update(deltaTime: number) {
    this.x += this.velocityX * (deltaTime / 1000);
    this.y += this.velocityY * (deltaTime / 1000);
  }

  render(ctx: CanvasRenderingContext2D) {
    const currentTime = Date.now();
    
    // Magical energy trail
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 6;
    
    // Draw bullet core
    ctx.fillStyle = this.color;
    ctx.fillRect(this.x, this.y, this.width, this.height);
    
    // Magical sparkle effect
    const sparkleIntensity = Math.sin(currentTime * 0.02) * 0.5 + 0.5;
    ctx.fillStyle = "#FFFFFF" + Math.floor(sparkleIntensity * 255).toString(16).padStart(2, '0');
    ctx.fillRect(this.x + 1, this.y + 1, this.width - 2, this.height - 2);
    
    // Special effects based on spell type
    if (this.pierce) {
      // Frost ray - icy trail
      ctx.fillStyle = "#87CEEB80";
      ctx.fillRect(this.x - 4, this.y, 4, this.height);
      
      // Ice crystals
      ctx.fillStyle = "#E0FFFF";
      ctx.fillRect(this.x - 2, this.y - 1, 1, 1);
      ctx.fillRect(this.x - 1, this.y + 2, 1, 1);
    } else if (this.color === "#FF4500") {
      // Flame burst - fire trail
      ctx.fillStyle = "#FFD70080";
      ctx.fillRect(this.x - 3, this.y, 3, this.height);
      
      // Fire sparks
      ctx.fillStyle = "#FF6347";
      ctx.fillRect(this.x - 1, this.y - 1, 1, 1);
      ctx.fillRect(this.x - 2, this.y + 2, 1, 1);
    } else {
      // Arcane bolt - mystical energy
      ctx.fillStyle = "#9370DB80";
      ctx.fillRect(this.x - 2, this.y, 2, this.height);
      
      // Magical runes
      ctx.fillStyle = "#DDA0DD";
      ctx.fillRect(this.x, this.y - 1, 1, 1);
      ctx.fillRect(this.x + 2, this.y + 1, 1, 1);
    }
    
    ctx.shadowBlur = 0;
  }
}
