export class Enemy {
  public x: number;
  public y: number;
  public width: number = 25;
  public height: number = 35;
  private speed: number = 50;
  private groundY: number;
  private canvasWidth: number;
  private canvasHeight: number;
  private animationTime: number = 0;
  public hp: number = 3;
  public isHit: boolean = false;
  private hitTimer: number = 0;

  constructor(x: number, y: number, canvasWidth: number, canvasHeight: number) {
    this.x = x;
    this.y = y;
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.groundY = canvasHeight - 50; // Ground level
    this.y = this.groundY - this.height; // Place on ground
    
    // Randomize enemy speed slightly
    this.speed = 50 + Math.random() * 50;
  }

  update(deltaTime: number) {
    // Move left
    this.x -= this.speed * (deltaTime / 1000);
    
    // Update animation timer
    this.animationTime += deltaTime;
    
    // Update hit effect timer
    if (this.hitTimer > 0) {
      this.hitTimer -= deltaTime / 16.67; // Approximate frame time at 60fps
    } else {
      this.isHit = false;
    }
  }

  takeDamage(): boolean {
    this.hp -= 1;
    this.isHit = true;
    this.hitTimer = 5; // Flash for about 5 frames
    return this.hp <= 0; // Return true if enemy should be removed
  }

  render(ctx: CanvasRenderingContext2D) {
    // Simple walking animation by slightly moving parts
    const walkOffset = Math.sin(this.animationTime * 0.01) * 2;

    // Draw enemy body with hit effect
    ctx.fillStyle = this.isHit ? "#FFFFFF" : "#F44336";
    ctx.fillRect(this.x, this.y + walkOffset, this.width, this.height);

    // Draw enemy head
    ctx.fillStyle = "#FF7043";
    ctx.fillRect(this.x + 3, this.y - 12 + walkOffset, 19, 12);

    // Draw simple weapon
    ctx.fillStyle = "#424242";
    ctx.fillRect(this.x - 10, this.y + 8 + walkOffset, 12, 4);

    // Draw legs with walking animation
    ctx.fillStyle = "#8BC34A";
    ctx.fillRect(this.x + 4, this.y + this.height - walkOffset, 6, 8);
    ctx.fillRect(this.x + 15, this.y + this.height + walkOffset, 6, 8);

    // Draw simple eyes
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(this.x + 6, this.y - 8 + walkOffset, 3, 3);
    ctx.fillRect(this.x + 16, this.y - 8 + walkOffset, 3, 3);
    
    ctx.fillStyle = "#000000";
    ctx.fillRect(this.x + 7, this.y - 7 + walkOffset, 1, 1);
    ctx.fillRect(this.x + 17, this.y - 7 + walkOffset, 1, 1);
  }
}
