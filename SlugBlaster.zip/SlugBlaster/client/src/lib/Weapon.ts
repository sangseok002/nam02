
export interface WeaponConfig {
  name: string;
  fireRate: number;
  bulletSpeed: number;
  bulletColor: string;
  spread: number;
  pierce?: boolean;
}

export class Weapon {
  public name: string;
  public fireRate: number;
  public bulletSpeed: number;
  public bulletColor: string;
  public spread: number;
  public pierce: boolean;

  constructor(config: WeaponConfig) {
    this.name = config.name;
    this.fireRate = config.fireRate;
    this.bulletSpeed = config.bulletSpeed;
    this.bulletColor = config.bulletColor;
    this.spread = config.spread;
    this.pierce = config.pierce || false;
  }

  static readonly PISTOL = new Weapon({
    name: "arcane bolt",
    fireRate: 300,
    bulletSpeed: 8,
    bulletColor: "#E6E6FA",
    spread: 0
  });

  static readonly SHOTGUN = new Weapon({
    name: "flame burst",
    fireRate: 700,
    bulletSpeed: 6,
    bulletColor: "#FF4500",
    spread: 3
  });

  static readonly LASER = new Weapon({
    name: "frost ray",
    fireRate: 200,
    bulletSpeed: 15,
    bulletColor: "#00BFFF",
    spread: 0,
    pierce: true
  });
}
