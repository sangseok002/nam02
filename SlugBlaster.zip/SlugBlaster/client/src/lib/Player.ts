import { InputHandler } from "./InputHandler";
import { Bullet } from "./Bullet";
import { Weapon } from "./Weapon";

export class Player {
  public x: number;
  public y: number;
  public width: number = 30;
  public height: number = 40;
  private velocityX: number = 0;
  private velocityY: number = 0;
  private speed: number = 200;
  private jumpPower: number = 400;
  private gravity: number = 800;
  private isGrounded: boolean = false;
  private groundY: number;
  private canvasWidth: number;
  private canvasHeight: number;
  private lastShotTime: number = 0;
  private direction: 'left' | 'right' = 'right'; // Current facing direction
  public currentWeapon: Weapon = Weapon.PISTOL;
  public weaponTimer: number = 0; // Special weapon duration in milliseconds

  constructor(x: number, y: number, canvasWidth: number, canvasHeight: number) {
    this.x = x;
    this.y = y;
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.groundY = canvasHeight - 50; // Ground level
  }

  update(deltaTime: number, inputHandler: InputHandler) {
    // Handle horizontal movement
    this.velocityX = 0;
    
    if (inputHandler.isKeyPressed("KeyA") || inputHandler.isKeyPressed("ArrowLeft")) {
      this.velocityX = -this.speed;
      this.direction = 'left';
    }
    if (inputHandler.isKeyPressed("KeyD") || inputHandler.isKeyPressed("ArrowRight")) {
      this.velocityX = this.speed;
      this.direction = 'right';
    }

    // Handle jumping
    if ((inputHandler.isKeyPressed("KeyW") || inputHandler.isKeyPressed("ArrowUp") || inputHandler.isKeyPressed("KeyZ")) && this.isGrounded) {
      this.velocityY = -this.jumpPower;
      this.isGrounded = false;
    }

    // Apply gravity
    if (!this.isGrounded) {
      this.velocityY += this.gravity * (deltaTime / 1000);
    }

    // Update position
    this.x += this.velocityX * (deltaTime / 1000);
    this.y += this.velocityY * (deltaTime / 1000);

    // Check ground collision
    if (this.y + this.height >= this.groundY) {
      this.y = this.groundY - this.height;
      this.velocityY = 0;
      this.isGrounded = true;
    }

    // Keep player within canvas bounds
    this.x = Math.max(0, Math.min(this.x, this.canvasWidth - this.width));

    // Update weapon timer
    if (this.weaponTimer > 0) {
      this.weaponTimer -= deltaTime;
      if (this.weaponTimer <= 0) {
        this.currentWeapon = Weapon.PISTOL; // Return to default weapon
        this.weaponTimer = 0;
      }
    }
  }

  canShoot(): boolean {
    const currentTime = Date.now();
    return currentTime - this.lastShotTime >= this.currentWeapon.fireRate;
  }

  shoot(): Bullet[] {
    if (!this.canShoot()) return [];
    
    this.lastShotTime = Date.now();
    const bullets: Bullet[] = [];
    
    // Calculate bullet starting position based on direction
    const bulletX = this.direction === 'right' ? this.x + this.width : this.x;
    const bulletY = this.y + this.height / 2;
    const directionMultiplier = this.direction === 'right' ? 1 : -1;
    
    if (this.currentWeapon.spread > 0) {
      // Shotgun-style spread
      for (let i = -this.currentWeapon.spread; i <= this.currentWeapon.spread; i++) {
        bullets.push(new Bullet(
          bulletX,
          bulletY,
          directionMultiplier * this.currentWeapon.bulletSpeed * 40, // Convert to pixels per second
          i * 48, // Vertical spread
          this.currentWeapon.bulletColor,
          this.currentWeapon.pierce
        ));
      }
    } else {
      // Single bullet
      bullets.push(new Bullet(
        bulletX,
        bulletY,
        directionMultiplier * this.currentWeapon.bulletSpeed * 40,
        0,
        this.currentWeapon.bulletColor,
        this.currentWeapon.pierce
      ));
    }
    
    return bullets;
  }

  render(ctx: CanvasRenderingContext2D) {
    const centerX = this.x + this.width / 2;
    const centerY = this.y + this.height / 2;
    
    // Draw magical aura/glow around character
    const currentTime = Date.now();
    const pulseIntensity = Math.sin(currentTime * 0.005) * 0.3 + 0.7;
    ctx.shadowColor = "#C0C0C0";
    ctx.shadowBlur = 8 * pulseIntensity;
    
    // Draw flowing cape/cloak
    ctx.fillStyle = "#2A1B3D";
    if (this.direction === 'right') {
      ctx.fillRect(this.x - 8, this.y + 5, 12, this.height - 5);
    } else {
      ctx.fillRect(this.x + this.width - 4, this.y + 5, 12, this.height - 5);
    }
    
    // Draw main body (futuristic outfit)
    const gradient = ctx.createLinearGradient(this.x, this.y, this.x, this.y + this.height);
    gradient.addColorStop(0, "#4A4A4A");
    gradient.addColorStop(0.5, "#6A6A6A");
    gradient.addColorStop(1, "#3A3A3A");
    ctx.fillStyle = gradient;
    ctx.fillRect(this.x + 3, this.y, this.width - 6, this.height);
    
    // Draw magical armor details
    ctx.fillStyle = "#8A2BE2";
    ctx.fillRect(this.x + 8, this.y + 8, 4, 15); // Chest armor detail
    ctx.fillRect(this.x + 18, this.y + 8, 4, 15);
    
    // Draw runes on armor
    ctx.fillStyle = "#E6E6FA";
    ctx.fillRect(this.x + 9, this.y + 10, 2, 2);
    ctx.fillRect(this.x + 19, this.y + 10, 2, 2);
    ctx.fillRect(this.x + 14, this.y + 15, 2, 2);
    
    // Draw head (pale skin)
    ctx.fillStyle = "#F5F5DC";
    ctx.fillRect(this.x + 6, this.y - 14, 18, 14);
    
    // Draw silver hair
    ctx.fillStyle = "#C0C0C0";
    // Hair base
    ctx.fillRect(this.x + 4, this.y - 16, 22, 8);
    // Hair strands
    ctx.fillRect(this.x + 2, this.y - 12, 4, 12);
    ctx.fillRect(this.x + 24, this.y - 12, 4, 12);
    // Long flowing hair
    if (this.direction === 'right') {
      ctx.fillRect(this.x - 2, this.y - 8, 6, 20);
    } else {
      ctx.fillRect(this.x + 26, this.y - 8, 6, 20);
    }
    
    // Draw deep blue eyes
    ctx.fillStyle = "#191970";
    ctx.fillRect(this.x + 9, this.y - 10, 2, 1);
    ctx.fillRect(this.x + 19, this.y - 10, 2, 1);
    
    // Draw magical gun based on direction and current weapon
    const gunGradient = ctx.createLinearGradient(0, 0, 20, 0);
    gunGradient.addColorStop(0, "#2F2F2F");
    gunGradient.addColorStop(0.5, this.currentWeapon.bulletColor);
    gunGradient.addColorStop(1, "#1F1F1F");
    ctx.fillStyle = gunGradient;
    
    if (this.direction === 'right') {
      // Gun body
      ctx.fillRect(this.x + this.width, this.y + 8, 18, 6);
      // Gun barrel with magical energy
      ctx.fillStyle = this.currentWeapon.bulletColor;
      ctx.fillRect(this.x + this.width + 18, this.y + 10, 8, 2);
      // Magical crystal on gun
      ctx.fillStyle = "#E6E6FA";
      ctx.fillRect(this.x + this.width + 2, this.y + 6, 3, 3);
    } else {
      // Gun body
      ctx.fillRect(this.x - 18, this.y + 8, 18, 6);
      // Gun barrel with magical energy
      ctx.fillStyle = this.currentWeapon.bulletColor;
      ctx.fillRect(this.x - 26, this.y + 10, 8, 2);
      // Magical crystal on gun
      ctx.fillStyle = "#E6E6FA";
      ctx.fillRect(this.x - 5, this.y + 6, 3, 3);
    }
    
    // Draw boots/legs with magical details
    ctx.fillStyle = "#1A1A1A";
    ctx.fillRect(this.x + 6, this.y + this.height, 7, 12);
    ctx.fillRect(this.x + 17, this.y + this.height, 7, 12);
    
    // Magical boot runes
    ctx.fillStyle = this.currentWeapon.bulletColor;
    ctx.fillRect(this.x + 8, this.y + this.height + 2, 3, 1);
    ctx.fillRect(this.x + 19, this.y + this.height + 2, 3, 1);
    
    // Clear shadow for other elements
    ctx.shadowBlur = 0;
    
    // Draw mystical energy around character when using special weapons
    if (this.weaponTimer > 0 && this.currentWeapon !== Weapon.PISTOL) {
      const energyIntensity = Math.sin(currentTime * 0.01) * 0.5 + 0.5;
      ctx.fillStyle = this.currentWeapon.bulletColor + "40";
      ctx.fillRect(this.x - 2, this.y - 2, this.width + 4, this.height + 4);
      
      // Energy particles
      for (let i = 0; i < 3; i++) {
        const offsetX = Math.sin(currentTime * 0.008 + i) * 10;
        const offsetY = Math.cos(currentTime * 0.006 + i) * 8;
        ctx.fillStyle = this.currentWeapon.bulletColor + "80";
        ctx.fillRect(centerX + offsetX, centerY + offsetY, 2, 2);
      }
    }

    // Draw weapon timer bar if using special weapon
    if (this.weaponTimer > 0 && this.currentWeapon !== Weapon.PISTOL) {
      const barWidth = 30;
      const barHeight = 4;
      const barX = this.x;
      const barY = this.y - 25;
      const fillWidth = (this.weaponTimer / 10000) * barWidth;

      // Background
      ctx.fillStyle = "#1A1A1A";
      ctx.fillRect(barX, barY, barWidth, barHeight);
      
      // Fill with magical energy
      const timerGradient = ctx.createLinearGradient(barX, barY, barX + fillWidth, barY);
      timerGradient.addColorStop(0, this.currentWeapon.bulletColor);
      timerGradient.addColorStop(1, this.currentWeapon.bulletColor + "AA");
      ctx.fillStyle = timerGradient;
      ctx.fillRect(barX, barY, fillWidth, barHeight);
      
      // Magical border
      ctx.strokeStyle = "#E6E6FA";
      ctx.lineWidth = 1;
      ctx.strokeRect(barX, barY, barWidth, barHeight);
    }

    // Draw weapon name with mystical font
    if (this.currentWeapon !== Weapon.PISTOL) {
      ctx.fillStyle = "#E6E6FA";
      ctx.font = "bold 11px serif";
      ctx.textAlign = "center";
      ctx.strokeStyle = "#2A1B3D";
      ctx.lineWidth = 2;
      ctx.strokeText(this.currentWeapon.name.toUpperCase(), centerX, this.y - 30);
      ctx.fillText(this.currentWeapon.name.toUpperCase(), centerX, this.y - 30);
    }
  }

  pickupWeapon(weapon: Weapon) {
    this.currentWeapon = weapon;
    this.weaponTimer = 10000; // 10 seconds in milliseconds
  }
}
