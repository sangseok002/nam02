import { useState } from "react";
import Game from "./components/Game";
import CharacterSelection from "./components/CharacterSelection";
import "./index.css";

interface Character {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  speciality: string;
}

function App() {
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [gameStarted, setGameStarted] = useState(false);

  const handleCharacterSelect = (character: Character) => {
    setSelectedCharacter(character);
    setGameStarted(true);
  };

  const handleBackToSelection = () => {
    setGameStarted(false);
    setSelectedCharacter(null);
  };

  if (!gameStarted) {
    return <CharacterSelection onCharacterSelect={handleCharacterSelect} />;
  }

  return (
    <div className="w-full h-full bg-gray-900 flex items-center justify-center">
      <Game selectedCharacter={selectedCharacter} onBackToSelection={handleBackToSelection} />
    </div>
  );
}

export default App;
